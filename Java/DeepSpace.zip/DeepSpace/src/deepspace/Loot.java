package deepspace;


import java.util.logging.Logger;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author victor
 */
class Loot {
    private int nSupplies, nWeapons, nShields, nHangars, nMedals;

    Loot(int nSupplies, int nWeapons, int nShields, int nHangars, int nMedals) {
        this.nSupplies = nSupplies;
        this.nWeapons = nWeapons;
        this.nShields = nShields;
        this.nHangars = nHangars;
        this.nMedals = nMedals;
    }   

    public int getnSupplies() {
        return nSupplies;
    }

    public int getnWeapons() {
        return nWeapons;
    }

    public int getnShields() {
        return nShields;
    }

    public int getnHangars() {
        return nHangars;
    }

    public int getnMedals() {
        return nMedals;
    }

    @Override
    public String toString() {
        return "Loot{" + "nSupplies=" + nSupplies + ", nWeapons=" + nWeapons + ", nShields=" + nShields + ", nHangars=" + nHangars + ", nMedals=" + nMedals + '}';
    }
    
    
    
    
    
}
