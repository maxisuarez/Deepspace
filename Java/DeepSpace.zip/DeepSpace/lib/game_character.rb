#encoding:utf-8
module GameCharacter
  ENEMYSTARSHIP=:enemystarship
  SPACESTATION=:spacestation    
end
